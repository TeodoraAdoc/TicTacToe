#include <hidef.h>      /* common defines and macros */
#include <mc9s12dg256.h>     /* derivative information */
#include <time.h>
#pragma LINK_INFO DERIVATIVE "mc9s12dg256b"



#define LCD_DATA PORTK
#define LCD_CTRL PORTK
#define RS 0x01
#define EN 0x02

void COMWRT4(unsigned char);
void DATWRT4(unsigned char);
void MSDelay(unsigned int);
void INIT_PORT();
void INIT_DISPLAY();
void PRINT_TABELA();
void TRANSMIT_SERIAL(unsigned char character);
unsigned char RECEIVE_SERIAL();
void IN_MESSAGE();
void PLAY_MESSAGE();
void NEW_LINE();
void PLAYER_TURN(unsigned char c);
void INIT_VECTOR();
void CHANGE_PLAYER();
int CHECK_WINNER();
int CHECK_DRAW();

void ALGORITHM();
int SELECT_MOVE();
int FIRST_MOVE_ON_BOARD();
int SECOND_MOVE_ON_BOARD(int previous_move);
int PATH_IF_O_IS_NOT_IN_CENTER(int previous_move);
int TEST_SECOND_MOVE(int first_move, int second_move);
int PATH_IF_O_IS_IN_CENTER(int first_move);
int METHOD_X_IN_OPPOSITE_CORNER(int first_move);
int METHOD_X_ON_A_EDGE(int first_move);
int THIRD_MOVE_ON_BOARD(int first_move, int second_move);
int TEST_IF_CAN_WIN(int first_move, int second_move);
int METHOD_X_IN_LINE_WITH_FIRST_AND_SECOND_X(int first_move, int second_move);
int METHOD_X_IN_LAST_EMPTY_CORNER();
int METHOD_X_BLOCK_O_FROM_WIN(int first_move, int second_move);
int TRY_TO_WIN();



unsigned char ch;
unsigned char V_pos[9];
unsigned int v_first_move[] = { 0,2,6,8 };
int win_move[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 0, 3, 6, 1, 4, 7, 2, 5, 8, 0, 4, 8, 2, 4, 6 };
unsigned char current_player = 'X';
unsigned int select_method_for_third_move;
unsigned int first_move = 0;
unsigned int second_move = 0;
unsigned int third_move = 0;
unsigned int four_move = 0;

void main(void) {
  /* put your own code here */
  unsigned int i;
  INIT_PORT();
  INIT_VECTOR();
  INIT_DISPLAY();
  IN_MESSAGE();
  while(1) {
    PLAYER_TURN(current_player);
    if(current_player == 'X') {
      ALGORITHM(); 
    }else{
      PLAY_MESSAGE();
    }
    if(CHECK_WINNER()) {
      PRINT_TABELA();
      break;
    }
    if(CHECK_DRAW()){
      PRINT_TABELA();
      break;
    }
    PRINT_TABELA();
    CHANGE_PLAYER();
  }
  for(;;) {}
}

void ALGORITHM() {

	int current_move = 0;
	
	current_move = SELECT_MOVE();

	switch (current_move)
	{
	case 0:
		first_move = FIRST_MOVE_ON_BOARD();
		break;
	case 1:
		second_move = SECOND_MOVE_ON_BOARD(first_move);
		break;
	case 2:
		third_move = THIRD_MOVE_ON_BOARD(first_move, second_move);
		break;
	case 3:
		four_move = TRY_TO_WIN();
		break;
	default:
		break;
	}

}

int SELECT_MOVE()
{
	int i, count = 0;
	for (i = 0; i < 9; i++)
	{
		if (V_pos[i] == 'X')
		{
			count++;
		}
	}
	return count;
}

int FIRST_MOVE_ON_BOARD() {
	int random_nr = rand() % 4;
	V_pos[v_first_move[random_nr]] = current_player;
	return v_first_move[random_nr];
}

int SECOND_MOVE_ON_BOARD(int previous_move) {
	int select_method = rand() % 2;
	if (V_pos[4] != 'O')
	{
		return PATH_IF_O_IS_NOT_IN_CENTER(previous_move);
	}
	return PATH_IF_O_IS_IN_CENTER(previous_move);
	
}

int PATH_IF_O_IS_NOT_IN_CENTER(int previous_move)
{
	int random_move = rand() % 4;
	while ((v_first_move[random_move] == previous_move) || (!TEST_SECOND_MOVE(previous_move, v_first_move[random_move])))
	{
		random_move = rand() % 4;
	}
	V_pos[v_first_move[random_move]] = current_player;
	return v_first_move[random_move];
}

int TEST_SECOND_MOVE(int first_move, int posible_move)
{
	int v_for_test_move[] = { 0,1,2,0,3,6,0,4,8,2,1,0,2,5,8,2,4,6,6,3,0,6,4,2,6,7,8,8,7,6,8,5,2,8,4,0 };
	int first_pos = 0;
	int second_pos = 1;
	int third_pos = 2;
	int i;

	for (i = 0; i < 12; i++)
	{
		if (( first_move == v_for_test_move[first_pos]) && (V_pos[v_for_test_move[second_pos]] == '-') && (posible_move == v_for_test_move[third_pos]) && (V_pos[v_for_test_move[third_pos]] == '-'))
		{
			return 1;
		}
		first_pos += 3;
		second_pos += 3;
		third_pos += 3;
	}
	return 0;
}

int PATH_IF_O_IS_IN_CENTER(int first_move)
{
	int random_select = rand() % 2;
	if (random_select)
	{
		select_method_for_third_move = 1;
		return METHOD_X_IN_OPPOSITE_CORNER(first_move);
	}
	select_method_for_third_move = 2;
	return METHOD_X_ON_A_EDGE(first_move);
}

int METHOD_X_IN_OPPOSITE_CORNER(int first_move) {
	int v_for_select_move[] = { 0,8,2,6,8,0,6,2 };
	int first_corner = 0;
	int possible_corner = 1;
	int i;
	for (i = 0; i < 4; i++)
	{
		if (first_move == v_for_select_move[first_corner])
		{
			V_pos[v_for_select_move[possible_corner]] = current_player;
			return v_for_select_move[possible_corner];
		}
		first_corner += 2;
		possible_corner += 2;
	}
	return 9;
}

int METHOD_X_ON_A_EDGE(int first_move) {
	int v_for_second_move[] = { 0,5,7,2,3,7,6,1,5,8,1,3 };
	int v_to_use[2];
	int random_selec = rand() % 2;
	int first_pos = 0;
	int second_pos = 1;
	int third_pos = 2;
	int i;
	for (i = 0; i < 4; i++)
	{
		if (first_move == v_for_second_move[first_pos])
		{
			v_to_use[0] = v_for_second_move[second_pos];
			v_to_use[1] = v_for_second_move[third_pos];
			V_pos[v_to_use[random_selec]] = current_player;
			return v_to_use[random_selec];
		}
		first_pos += 3;
		second_pos += 3;
		third_pos += 3;
	}
	return 9;
}

int THIRD_MOVE_ON_BOARD(int first_move, int second_move)
{
	int posible_win;
	switch (select_method_for_third_move)
	{
		case 0:
			posible_win = TEST_IF_CAN_WIN(first_move, second_move);
			if (posible_win != 9)
			{
				V_pos[posible_win] = current_player;
				return posible_win;
			}
			else
			{
				return METHOD_X_IN_LINE_WITH_FIRST_AND_SECOND_X(first_move, second_move);
			}
			break;
		case 1:
			return METHOD_X_IN_LAST_EMPTY_CORNER();
			break;
		case 2:
			return METHOD_X_BLOCK_O_FROM_WIN(first_move, second_move);
			break;
	default:
		break;
	}
	return 9;
}

int TEST_IF_CAN_WIN(int first_move, int second_move)
{
	int i;
	int first_pos = 0;
	int second_pos = 1;
	int third_pos = 2;
	int v_for_select_move[] = { 0,1,2,0,4,8,0,3,6,2,1,0,2,5,8,2,4,6,6,7,8,6,3,0,6,4,2,8,5,2,8,7,6,8,4,0 };
	for (i = 0; i < 12; i++)
	{
		if ((first_move == v_for_select_move[first_pos]) && (second_move == v_for_select_move[third_pos]) && (V_pos[v_for_select_move[second_pos]] == '-'))
		{
			return v_for_select_move[second_pos];
		}
		first_pos += 3;
		second_pos += 3;
		third_pos += 3;
	}
	return 9;
}

int METHOD_X_IN_LINE_WITH_FIRST_AND_SECOND_X(int first_move, int second_move)
{
	int v_for_select_move[] = { 0,1,2,0,4,8,0,3,6,2,1,0,2,5,8,2,4,6,6,7,8,6,3,0,6,4,2,8,5,2,8,7,6,8,4,0 };
	int i,j;
	int first_pos_f_x = 0;
	int second_pos_f_x = 1;
	int third_pos_f_x = 2;
	int first_pos_s_x = 0;
	int second_pos_s_x = 1;
	int third_pos_s_x = 2;
	int aux_first_move;
	int aux_second_move;
	
	for (i = 0; i < 12; i++)
	{
		if ((first_move == v_for_select_move[first_pos_f_x]) && (V_pos[v_for_select_move[second_pos_f_x]] == '-') && (V_pos[v_for_select_move[third_pos_f_x]] == '-'))
		{
			aux_first_move = v_for_select_move[third_pos_f_x];
			for (j = 0; j < 12; j++)
			{
				if ((second_move == v_for_select_move[first_pos_s_x]) && (V_pos[v_for_select_move[second_pos_s_x]] == '-') && (V_pos[v_for_select_move[third_pos_s_x]] == '-'))
				{
					aux_second_move = v_for_select_move[third_pos_s_x];
					if (aux_first_move == aux_second_move)
					{
						V_pos[aux_first_move] = current_player;
						return aux_first_move;
					}
				}
				first_pos_s_x += 3;
				second_pos_s_x += 3;
				third_pos_s_x += 3;
			}
		}
		
		first_pos_f_x += 3;
		second_pos_f_x += 3;
		third_pos_f_x += 3;
	}
	return 9;
}

int METHOD_X_IN_LAST_EMPTY_CORNER()
{
	int i;
	int empty_corner = 0;
	int posible_move;
	for (i = 0; i < 4; i++)
	{
		if (V_pos[v_first_move[i]] == '-')
		{
			empty_corner++;
			posible_move = v_first_move[i];
		}
	}
	if (empty_corner == 1)
	{
		V_pos[posible_move] = current_player;
		return posible_move;
	}
	return 9;
}

int METHOD_X_BLOCK_O_FROM_WIN(int first_move, int second_move)
{
	int v_for_select_move[] = { 0,5,6,2,0,7,2,6,2,3,8,0,2,7,0,8,6,1,8,0,6,5,0,8,8,1,6,2,8,3,2,6 };
	int first_pos = 0;
	int second_pos = 1;
	int third_pos = 2;
	int four_pos = 3;
	int i;
	for (i = 0; i < 8; i++)
	{
		if ((first_move == v_for_select_move[first_pos]) && (second_move == v_for_select_move[second_pos]) && (V_pos[v_for_select_move[third_pos]] == 'O'))
		{
			V_pos[v_for_select_move[four_pos]] = current_player;
			return four_pos;
		}
		first_pos += 4;
		second_pos += 4;
		third_pos += 4;
		four_pos += 4;
	}
	return 9;

}

int TRY_TO_WIN() {
	int i;
	int pos_left = 0;
	int pos_midl = 1;
	int pos_right = 2;
	for (i = 0; i < 8; i++)
	{
		if ((V_pos[win_move[pos_left]] == 'X') && (V_pos[win_move[pos_midl]] == 'X') && (V_pos[win_move[pos_right]] == '-')) {
			V_pos[win_move[pos_right]] = current_player;
			return win_move[pos_right];
		}
		if ((V_pos[win_move[pos_left]] == 'X') && (V_pos[win_move[pos_midl]] == '-') && (V_pos[win_move[pos_right]] == 'X')) {
			V_pos[win_move[pos_midl]] = current_player;
			return win_move[pos_midl];
			
		}
		if ((V_pos[win_move[pos_left]] == '-') && (V_pos[win_move[pos_midl]] == 'X') && (V_pos[win_move[pos_right]] == 'X')) {
			V_pos[win_move[pos_left]] = current_player;
			return win_move[pos_left];
		}
		pos_left += 3;
		pos_midl += 3;
		pos_right += 3;
	}
	return 9;
}

void INIT_PORT(){
  SCI0BDH=0x00;
  SCI0BDL=26;
  SCI0CR1=0x00;
  SCI0CR2=0x0C;
}

void INIT_DISPLAY(){
  DDRK = 0xFF;   
  COMWRT4(0x33);   //reset sequence provided by data sheet
  MSDelay(1);
  COMWRT4(0x32);   //reset sequence provided by data sheet
  MSDelay(1);
  COMWRT4(0x28);   //Function set to four bit data length
                                         //2 line, 5 x 7 dot format
  MSDelay(1);
  COMWRT4(0x06);  //entry mode set, increment, no shift
  MSDelay(1);
  COMWRT4(0x0E);  //Display set, disp on, cursor on, blink off
  MSDelay(1);
  COMWRT4(0x01);  //Clear display
  MSDelay(1);
  COMWRT4(0x80);  //set start posistion, home position
  MSDelay(1);
}

void COMWRT4(unsigned char command){
  unsigned char x;
  x = (command & 0xF0) >> 2;         //shift high nibble to center of byte for Pk5-Pk2
  LCD_DATA =LCD_DATA & ~0x3C;          //clear bits Pk5-Pk2
  LCD_DATA = LCD_DATA | x;          //sends high nibble to PORTK
  MSDelay(1);
  LCD_CTRL = LCD_CTRL & ~RS;         //set RS to command (RS=0)
  MSDelay(1);
  LCD_CTRL = LCD_CTRL | EN;          //rais enable
  MSDelay(5);
  LCD_CTRL = LCD_CTRL & ~EN;         //Drop enable to capture command
  MSDelay(15);                       //wait
  x = (command & 0x0F)<< 2;          // shift low nibble to center of byte for Pk5-Pk2
  LCD_DATA =LCD_DATA & ~0x3C;         //clear bits Pk5-Pk2
  LCD_DATA =LCD_DATA | x;             //send low nibble to PORTK
  LCD_CTRL = LCD_CTRL | EN;          //rais enable
  MSDelay(5);
  LCD_CTRL = LCD_CTRL & ~EN;         //drop enable to capture command
  MSDelay(15);
}

void DATWRT4(unsigned char data){
  unsigned char x;
  x = (data & 0xF0) >> 2;
  LCD_DATA =LCD_DATA & ~0x3C;                     
  LCD_DATA = LCD_DATA | x;
  MSDelay(1);
  LCD_CTRL = LCD_CTRL | RS;
  MSDelay(1);
  LCD_CTRL = LCD_CTRL | EN;
  MSDelay(1);
  LCD_CTRL = LCD_CTRL & ~EN;
  MSDelay(5);
  x = (data & 0x0F)<< 2;
  LCD_DATA =LCD_DATA & ~0x3C;                     
  LCD_DATA = LCD_DATA | x;
  LCD_CTRL = LCD_CTRL | EN;
  MSDelay(1);
  LCD_CTRL = LCD_CTRL & ~EN;
  MSDelay(15);     
}


void MSDelay(unsigned int itime){
    unsigned int i; 
    unsigned int j;
    for(i=0;i<itime;i++)
      for(j=0;j<4000;j++);
 }

void TRANSMIT_SERIAL(unsigned char character){
   while(!(SCI0SR1 & 0x80));
   SCI0DRL = character;
}

unsigned char RECEIVE_SERIAL(){
   unsigned char c;
   while(!(SCI0SR1 & 0x20));
   c = SCI0DRL;
   return c;
   
}

void PRINT_TABELA(){
  int i,j,l,k=0;
  unsigned char linie[] = "----+---+----";
  NEW_LINE();
  for(i=0; i < strlen(linie); i++){
    TRANSMIT_SERIAL(linie[i]);  
  }
  NEW_LINE();
  for(i = 0; i < 3; i++){
    TRANSMIT_SERIAL('|');
    TRANSMIT_SERIAL(' ');
    for(j = 0;j < 3; j++){
      TRANSMIT_SERIAL(V_pos[k]);
      TRANSMIT_SERIAL(' ');
      TRANSMIT_SERIAL('|');
      TRANSMIT_SERIAL(' ');
      k++;
    }
      NEW_LINE();
      for(l=0; l<strlen(linie); l++){
        TRANSMIT_SERIAL(linie[l]);  
      }
      NEW_LINE();
  } 
}

void IN_MESSAGE(){
 unsigned int i;
 unsigned char st1[] = "The object of Tic Tac Toe is to get three in a row.You play on a three by three game board.";
 unsigned char st2[] = "Players alternate placing Xs and Os on the game board until either oppent has three in a row or all nine squares are filled. X always goes first.";
 
 for(i=0;i<strlen(st1);i++){
  TRANSMIT_SERIAL(st1[i]);
 }
 for(i=0;i<strlen(st2);i++){
  TRANSMIT_SERIAL(st2[i]);
 }
   NEW_LINE();
}

void NEW_LINE(){
  TRANSMIT_SERIAL(0x0D);
  MSDelay(50);
  TRANSMIT_SERIAL(0x0A);
}

void PLAYER_TURN(unsigned char c){
  unsigned char st[] = " - player turn!";
  unsigned int i;
  TRANSMIT_SERIAL(c);
  for(i=0;i<strlen(st);i++){
    TRANSMIT_SERIAL(st[i]);
  }
  NEW_LINE();
  
}

void PLAY_MESSAGE(){
  unsigned char st1[] = "Enter row: ";
  unsigned char st2[] = "Enter col: ";
  unsigned char st3[] = "Invalid move!";
  unsigned char row,col;
  unsigned int i;
  unsigned int valid_move = 0;
  for(i=0;i<strlen(st1);i++){
   TRANSMIT_SERIAL(st1[i]);
  }
  row=RECEIVE_SERIAL();
  TRANSMIT_SERIAL(row);
  NEW_LINE();
  for(i=0;i<strlen(st2);i++){
   TRANSMIT_SERIAL(st2[i]);
  }
  col=RECEIVE_SERIAL();
  TRANSMIT_SERIAL(col);
  while(!valid_move){
    if(row == '1' && V_pos[((col-48)-1)] == '-'){
      V_pos[((col-48)-1)] = current_player;
      valid_move = 1;
    }
    if(row == '2' && V_pos[(row - 48) + (col - 48)] == '-'){
      V_pos[(row - 48) + (col - 48)] = current_player;
      valid_move = 1;
    }
    if(row == '3' && V_pos[(row - 48) + (col - 48) + 2] == '-'){
      V_pos[(row - 48) + (col - 48) + 2] = current_player;
      valid_move = 1;
    }
    if(!valid_move){
      NEW_LINE();
      for(i=0;i<strlen(st3); i++){
        TRANSMIT_SERIAL(st3[i]);
      }
      NEW_LINE();
      for(i=0;i<strlen(st1);i++){
        TRANSMIT_SERIAL(st1[i]);
      }
      row=RECEIVE_SERIAL();
      TRANSMIT_SERIAL(row);
      NEW_LINE();
      for(i=0;i<strlen(st2);i++){
        TRANSMIT_SERIAL(st2[i]);
      }
      col=RECEIVE_SERIAL();
      TRANSMIT_SERIAL(col);
    }
  }
}

int CHECK_WINNER(){
    unsigned int win_move[] = {
      0,1,2,3,4,5,6,7,8,0,3,6,1,4,7,2,5,8,0,4,8,2,4,6
    };
    unsigned char st1[] = "Player ";
    unsigned char st2[] = " wins!";
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int pos1=0;
    unsigned int pos2=1;
    unsigned int pos3=2;
    for(i=0; i < 8; i++){
      if((V_pos[win_move[pos1]] != '-') && (V_pos[win_move[pos1]] == V_pos[win_move[pos2]]) && (V_pos[win_move[pos2]] == V_pos[win_move[pos3]])){
        for(j=0;j<strlen(st1);j++){
          DATWRT4(st1[j]);
        }
        DATWRT4(current_player);
        for(j=0;j<strlen(st2);j++){
          DATWRT4(st2[j]);
        }
        return 1;  
      }  
      pos1+=3;
      pos2+=3;
      pos3+=3;
    }
    return 0;  
}

int CHECK_DRAW(){
  unsigned int i = 0;
  unsigned char st[] = "Draw!";
  for(i=0; i < 9; i++){
    if(V_pos[i] == '-'){
        return 0;
    }
  }
  for(i = 0; i < strlen(st); i++){
    DATWRT4(st[i]);  
  }
  return 1;
}

void INIT_VECTOR(){
  unsigned int i;
  for(i = 0; i< 9; i++){
    V_pos[i] = '-';
  }
}

void CHANGE_PLAYER(){
  if(current_player == 'X'){
    current_player = 'O';
  }else{
    current_player = 'X';
  }
}